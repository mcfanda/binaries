(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
var rtermFormat = require('./rtermFormat');

const events = {
    update: function(ui) {
        calcModelTerms(ui, this);
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);

    },

    onChange_factors: function(ui) {
        calcModelTerms(ui, this);

    },

    onChange_covariates: function(ui) {
        calcModelTerms(ui, this);

    },

    onChange_modelTerms: function(ui) {
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);

    },

    onChange_plotsSupplier: function(ui) {
        let values = this.itemsToValues(ui.plotsSupplier.value());
        this.checkValue(ui.plotHAxis, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepLines, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepPlots, false, values, FormatDef.variable);
    },
    
    onChange_simpleSupplier: function(ui) {
          console.log("change simple");
        let values = this.itemsToValues(ui.simpleSupplier.value());
        this.checkValue(ui.simpleVariable, false, values, FormatDef.variable);
        this.checkValue(ui.simpleModerator, false, values, FormatDef.variable);
        this.checkValue(ui.simple3way, false, values, FormatDef.variable);
    },

    onUpdate_simpleSupplier: function(ui) {
        updateSimpleSupplier(ui, this);
    },
    onUpdate_plotsSupplier: function(ui) {
        updatePlotsSupplier(ui, this);
    },

     onChange_model: function(ui) {
        console.log("model changed");
        if (typeof ui.effectSize_RR !== 'undefined' ) {
              ui.effectSize_RR.setValue(false);
        }
        if (ui.modelSelection.getValue()==="custom" ||  ui.modelSelection.getValue()==="linear") {
               ui.effectSize_expb.setValue(false);
               ui.showParamsCI.setValue(true);
               ui.showExpbCI.setValue(false);
        } else  {
               ui.effectSize_expb.setValue(true);
               ui.showParamsCI.setValue(false);
               ui.showExpbCI.setValue(true);
        }
  
        ui.dep.setValue(null);
      },

    onChange_postHocSupplier: function(ui) {
        let values = this.itemsToValues(ui.postHocSupplier.value());
        this.checkValue(ui.postHoc, true, values, FormatDef.term);
    },

    onUpdate_postHocSupplier: function(ui) {
        updatePostHocSupplier(ui, this);
    },
    
    onUpdate_modelSupplier: function(ui) {
            let factorsList = this.cloneArray(ui.factors.value(), []);
            let covariatesList = this.cloneArray(ui.covs.value(), []);
            var variablesList = factorsList.concat(covariatesList);
            ui.modelSupplier.setValue(this.valuesToItems(variablesList, FormatDef.variable));
    }
};

var calcModelTerms = function(ui, context) {
    var variableList = context.cloneArray(ui.factors.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var combinedList = variableList.concat(covariatesList);
    ui.modelSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.plotsSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.simpleSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
 
    var diff = context.findChanges("variableList", variableList, true, FormatDef.variable);
    var diff2 = context.findChanges("covariatesList", covariatesList, true, FormatDef.variable);
    var combinedDiff = context.findChanges("combinedList", combinedList, true, FormatDef.variable);


    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var termsChanged = false;

    for (var i = 0; i < combinedDiff.removed.length; i++) {
        for (var j = 0; j < termsList.length; j++) {
            if (FormatDef.term.contains(termsList[j], combinedDiff.removed[i])) {
                termsList.splice(j, 1);
                termsChanged = true;
                j -= 1;
            }
        }
    }


    for (var a = 0; a < diff.added.length; a++) {
        let item = diff.added[a];
        var listLength = termsList.length;
        for (var j = 0; j < listLength; j++) {
            var newTerm = context.clone(termsList[j]);
            if (containsCovariate(newTerm, covariatesList) === false) {
                if (context.listContains(newTerm, item, FormatDef.variable) === false) {
                    newTerm.push(item)
                    if (context.listContains(termsList, newTerm , FormatDef.term) === false) {
                        termsList.push(newTerm);
                        termsChanged = true;
                    }
                }
            }
        }
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    for (var a = 0; a < diff2.added.length; a++) {
        let item = diff2.added[a];
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    if (termsChanged)
        ui.modelTerms.setValue(termsList);

    updateContrasts(ui, variableList, context);
    updateScaling(ui, covariatesList, context);
};

var updateSimpleSupplier = function(ui, context) {
      
        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.simpleSupplier.setValue(varList);
    };

var updatePlotsSupplier = function(ui, context) {

        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.plotsSupplier.setValue(varList);
    
    };


var updatePostHocSupplier = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var list = [];
    for (var j = 0; j < termsList.length; j++) {
        var term = termsList[j];
        if (containsCovariate(term, covariatesList) === false)
            list.push(term);
    }
    ui.postHocSupplier.setValue(context.valuesToItems(list, FormatDef.term));
};

var filterModelTerms = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var diff = context.findChanges("termsList", termsList, true, FormatDef.term);

    var changed = false;
    if (diff.removed.length > 0) {
        var itemsRemoved = false;
        for (var i = 0; i < diff.removed.length; i++) {
            var item = diff.removed[i];
            for (var j = 0; j < termsList.length; j++) {
                if (FormatDef.term.contains(termsList[j], item)) {
                    termsList.splice(j, 1);
                    j -= 1;
                    itemsRemoved = true;
                }
            }
        }

        if (itemsRemoved)
            changed = true;
    }

    if (context.sortArraysByLength(termsList))
        changed = true;

    if (changed)
        ui.modelTerms.setValue(termsList);
};

var updateContrasts = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.contrasts.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "simple" });
        else
            list3.push(found);
    }

    ui.contrasts.setValue(list3);
};

var updateScaling = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.scaling.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "centered" });
        else
            list3.push(found);
    }

    ui.scaling.setValue(list3);
};

var containsCovariate = function(value, covariates) {
    for (var i = 0; i < covariates.length; i++) {
        if (FormatDef.term.contains(value, covariates[i]))
            return true;
    }

    return false;
};





module.exports = events;


},{"./rtermFormat":4}],2:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"dep","title":"Dependent Variable","type":"Variable","default":null,"description":{"R":"a string naming the dependent variable from `data`, variable must be numeric\n"}},{"name":"factors","title":"Factors","type":"Variables","permitted":["factor"],"default":null,"description":{"R":"a vector of strings naming the fixed factors from `data`"}},{"name":"covs","title":"Covariates","type":"Variables","permitted":["numeric"],"default":null,"description":{"R":"a vector of strings naming the covariates from `data`"}},{"name":"modelTerms","title":"Model Terms","type":"Terms","default":null,"description":{"R":"a list of character vectors describing fixed effects terms\n"}},{"name":"fixedIntercept","title":"Fixed Intercept","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, estimates fixed intercept\n"}},{"name":"showParamsCI","title":"For estimates","type":"Bool","default":false,"description":{"R":"`TRUE` (default) or `FALSE` , parameters CI in table\n"}},{"name":"showExpbCI","title":"For exp(B)","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE` , exp(B) CI in table\n"}},{"name":"paramCIWidth","title":"Confidence level","type":"Number","min":50,"max":99.9,"default":95,"description":{"R":"a number between 50 and 99.9 (default: 95) specifying the confidence interval width for the parameter estimates\n"}},{"name":"contrasts","title":"Factors Coding","type":"Array","items":"(factors)","default":null,"template":{"type":"Group","elements":[{"name":"var","type":"Variable","content":"$key"},{"name":"type","type":"List","options":["simple","deviation","dummy","difference","helmert","repeated","polynomial"],"default":"simple"}]},"description":{"R":"a list of lists specifying the factor and type of contrast to use, one of `'deviation'`, `'simple'`, `'difference'`, `'helmert'`, `'repeated'` or `'polynomial'`\n"}},{"name":"showRealNames","title":"Names in estimates table","type":"Bool","default":true,"description":{"R":"`TRUE` or `FALSE` (default), provide raw names of the contrasts variables\n"}},{"name":"showContrastCode","title":"Contrast Coefficients tables","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide contrast coefficients tables\n"}},{"name":"plotHAxis","title":"Horizontal axis","type":"Variable","default":null,"description":{"R":"a string naming the variable placed on the horizontal axis of the plot\n"}},{"name":"plotSepLines","title":"Separate lines","type":"Variable","default":null,"description":{"R":"a string naming the variable represented as separate lines on the plot\n"}},{"name":"plotSepPlots","title":"Separate plots","type":"Variable","default":null,"description":{"R":"the variable for whose levels multiple plots are computed\n"}},{"name":"plotRaw","title":"Observed scores","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide descriptive statistics\n"}},{"name":"plotDvScale","title":"Y-axis observed range","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), scale the plot Y-Axis to the max and the min of the dependent variable observed scores.\n"}},{"name":"plotError","title":"Error Bar Definition","type":"List","options":[{"name":"none","title":"None"},{"name":"ci","title":"Confidence intervals"},{"name":"se","title":"Standard Error"}],"default":"none","description":{"R":"`'none'`, `'ci'` (default), or `'se'`. Use no error bars, use confidence intervals, or use standard errors on the plots, respectively\n"}},{"name":"ciWidth","title":"Confidence level","type":"Number","min":50,"max":99.9,"default":95,"description":{"R":"a number between 50 and 99.9 (default: 95) specifying the confidence interval width\n"}},{"name":"postHoc","title":"Post Hoc Tests","type":"Terms","default":null,"description":{"R":"a list of terms to perform post-hoc tests on"}},{"name":"eDesc","title":"Estimated Marginal Means","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide lsmeans statistics\n"}},{"name":"eCovs","title":"Include covariates","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide lsmeans statistics\n"}},{"name":"simpleVariable","title":"Simple effects variable","type":"Variable","default":null,"description":{"R":"The variable for which the simple effects (slopes) are computed\n"}},{"name":"simpleModerator","title":"Moderator","type":"Variable","default":null,"description":{"R":"the variable that provides the levels at which the simple effects computed\n"}},{"name":"simple3way","title":"Breaking variable","type":"Variable","default":null,"description":{"R":"a moderator of the two-way interaction which is probed\n"}},{"name":"simpleScale","title":"Covariates conditioning","type":"List","options":[{"name":"mean_sd","title":"Mean ±  SD"},{"name":"percent","title":"Percentiles 50 ± offset"}],"default":"mean_sd","description":{"R":"`'mean_sd'` (default), `'custom'` , or `'custom_percent'`. Use to condition the covariates (if any)\n"}},{"name":"cvalue","type":"Number","default":1,"description":{"R":"offset value for conditioning\n"}},{"name":"percvalue","type":"Number","default":25,"min":5,"max":50,"description":{"R":"offset value for conditioning\n"}},{"name":"simpleScaleLabels","title":"Moderators labeling","type":"List","options":[{"name":"labels","title":"Labels"},{"name":"values","title":"Values"},{"name":"values_labels","title":"Values + Labels"}],"default":"labels","description":{"R":"decide the labeling of simple effects in tables and plots.  `labels` indicates that only labels are used, such as `Mean` and  `Mean + 1 SD`. `values` uses the actual values as labels. `values_labels` uses both.\n"}},{"name":"postHocCorr","title":"Correction","type":"NMXList","options":[{"name":"none","title":"No correction"},{"name":"bonf","title":"Bonferroni"},{"name":"holm","title":"Holm"}],"default":["bonf"],"description":{"R":"one or more of `'none'`,  `'bonf'`, or `'holm'`; provide no,  Bonferroni, and Holm Post Hoc corrections respectively\n"}},{"name":"scaling","title":"Covariates Scaling","type":"Array","items":"(covs)","default":null,"template":{"type":"Group","elements":[{"name":"var","type":"Variable","content":"$key"},{"name":"type","type":"List","options":["centered","standardized","cluster-based-centered","cluster-based-standardized","none"],"default":"centered"}]},"description":{"R":"a list of lists specifying the covariates scaling, one of `'centered to the mean'`, `'standardized'`, or `'none'`. `'none'` leaves the variable as it is\n"}},{"name":"cluster","title":"Cluster variables","type":"Variables","default":null,"suggested":["nominal"],"description":{"R":"a vector of strings naming the clustering variables from `data`"}},{"name":"randomTerms","title":"Random Coefficients","type":"Array","default":[[]],"template":{"type":"Terms"},"description":{"R":"a list of lists specifying the models random effects.          \n"}},{"name":"correlatedEffects","title":"Effects correlation","type":"List","options":[{"name":"corr","title":"Correlated"},{"name":"nocorr","title":"Not correlated"},{"name":"block","title":"Correlated by block"}],"default":"corr","description":{"R":"`'nocorr'`, `'corr'` (default), or `'block'`. When random effects are passed as list of length 1, it decides whether the effects should be correlated,  non correlated. If `'randomTerms'` is a list of  lists of length > 1, the option is automatially set to `'block'`. The option is ignored if the model is passed using `formula`.\n"}},{"name":"plotRandomEffects","title":"Random effects","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), add random effects predicted values in the plot\n"}},{"name":"plotLinearPred","title":"Linear Predictor","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), plot the predicted values in the linear predictor scale. If set, `plotRaw` and `plotDvScale` are ignored.\n"}},{"name":"nAGQ","title":"Precision/Speed","type":"Number","min":0,"max":25,"default":1,"description":{"R":"for the adaptive Gauss-Hermite log-likelihood approximation, nAGQ argument controls the number of nodes in the quadrature formula. A positive integer\n"}},{"name":"effectSize","title":"Effect Size","type":"NMXList","options":[{"name":"expb","title":"Odd Ratios (expB)"}],"default":["expb"]},{"name":"modelSelection","title":"Model Selection","type":"List","options":[{"name":"poisson","title":"Poisson"},{"name":"logistic","title":"Logistic"},{"name":"probit","title":"Probit"},{"name":"custom","title":"Custom"}],"default":"logistic","description":{"R":"Select the generalized linear model: `linear`,`poisson`,`logistic`,`multinomial`\n"}},{"name":"custom_family","title":"Distribution","type":"List","options":[{"title":"Gaussian","name":"gaussian"},{"title":"Binomial","name":"binomial"},{"title":"Poisson","name":"poisson"},{"title":"Inverse gaussian","name":"inverse.gaussian"},{"title":"Gamma","name":"Gamma"}],"default":"gaussian","description":{"R":"Distribution family for the custom model, accepts gaussian, binomial, gamma and inverse_gaussian .\n"}},{"name":"custom_link","title":"Link Function","type":"List","options":[{"title":"Identity","name":"identity"},{"title":"Logit","name":"logit"},{"title":"Log","name":"log"},{"title":"Inverse","name":"inverse"},{"title":"Inverse squared","name":"1/mu^2"},{"title":"Square root","name":"sqrt"}],"default":"identity","description":{"R":"Distribution family for the custom model, accepts  identity, log and inverse, onemu2 (for 1/mu^2).\n"}},{"name":"cimethod","title":"CI Method","type":"List","options":[{"name":"wald","title":"Wald (fast)"},{"name":"profile","title":"Profile (slow)"},{"name":"boot","title":"Bootstrap (very slow)"}]}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	],

	update: require('./mixed.events').update

    }).call(this);
}

view.layout = ui.extend({

    label: "Generalized Mixed Models",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			style: "inline",
			controls: [
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Categorical dependent variable",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "modelSelection_logistic",
									optionName: "modelSelection",
									optionPart: "logistic",
									events: [
										{ execute: require('./gamlj.events').onChange_model }
									]
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "modelSelection_probit",
									optionName: "modelSelection",
									optionPart: "probit",
									events: [
										{ execute: require('./gamlj.events').onChange_model }
									]
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Frequencies",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "modelSelection_poisson",
									optionName: "modelSelection",
									optionPart: "poisson",
									events: [
										{ execute: require('./gamlj.events').onChange_model }
									]
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Custom Model",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "modelSelection_custom",
									optionName: "modelSelection",
									optionPart: "custom",
									events: [
										{ execute: require('./gamlj.events').onChange_model }
									]
								},
								{
									type: DefaultControls.ComboBox,
									typeName: 'ComboBox',
									name: "custom_family",
									enable: "(modelSelection_custom)"
								},
								{
									type: DefaultControls.ComboBox,
									typeName: 'ComboBox',
									name: "custom_link",
									enable: "(modelSelection_custom)"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			name: "variablesupplier",
			suggested: ["continuous","nominal","ordinal"],
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "dep",
							maxItemCount: 1,
							isTarget: true,
							itemDropBehaviour: "overwrite"
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "factors",
							isTarget: true,
							events: [
								{ execute: require('./mixed.events').onChange_factors }
							]
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "covs",
							height: "small",
							isTarget: true,
							events: [
								{ execute: require('./mixed.events').onChange_covariates }
							]
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "cluster",
							height: "small",
							isTarget: true,
							events: [
								{ execute: require('./mixed.events').onChange_cluster }
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			style: "inline",
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Effect Size",
					margin: "large",
					style: "list",
					controls: [
						{
							name: "effectSize_expb",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							optionPart: "expb",
							optionName: "effectSize"
						}
					]
				},
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Confidence Intervals",
					margin: "large",
					style: "list",
					controls: [
						{
							name: "showExpbCI",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox'
						},
						{
							name: "showParamsCI",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox'
						},
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "paramCIWidth",
							label: "Interval",
							suffix: "%",
							format: FormatDef.number,
							enable: "(showParamsCI || showExpbCI)"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Fixed Effects",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Supplier,
					typeName: 'Supplier',
					name: "modelSupplier",
					label: "Components",
					persistentItems: true,
					higherOrders: true,
					stretchFactor: 1,
					format: FormatDef.term,
					events: [
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_modelSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							transferAction: "interactions",
							controls: [
								{
									type: DefaultControls.ListBox,
									typeName: 'ListBox',
									name: "modelTerms",
									valueFilter: "unique",
									isTarget: true,
									itemDropBehaviour: "emptyspace",
									events: [
										{ execute: require('./mixed.events').onChange_modelTerms }
									],
									template:
									{
										type: DefaultControls.TermLabel,
										typeName: 'TermLabel'
									}									
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "fixedIntercept"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Random Effects",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Supplier,
					typeName: 'Supplier',
					name: "randomSupplier",
					label: "Components",
					persistentItems: false,
					stretchFactor: 1,
					events: [
						{ execute: require('./mixed.events').onChange_randomSupplier },
						{ onEvent: 'update', execute: require('./mixed.events').onUpdate_randomSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							transferAction: "interactions",
							controls: [
								{
									type: DefaultControls.ListBox,
									typeName: 'ListBox',
									name: "randomTerms",
									height: "large",
									addButton: "Add block",
									events: [
										{ onEvent: 'listItemAdded', execute: require('./mixed.events').onEvent_nothing },
										{ onEvent: 'listItemRemoved', execute: require('./mixed.events').onEvent_nothing }
									],
									selectable: true,
									templateName: "linreg-block-template",
									template:
									{
										type: DefaultControls.LayoutBox,
										typeName: 'LayoutBox',
										margin: "normal",
										targetArea: true,
										controls: [
											{
												type: DefaultControls.ListBox,
												typeName: 'ListBox',
												name: "randblockList",
												isTarget: true,
												valueFilter: "unique",
												height: "auto",
												ghostText: "drag term here",
												events: [
													{ execute: require('./mixed.events').onEvent_addRandomTerm }
												],
												template:
												{
													type: DefaultControls.TermLabel,
													typeName: 'TermLabel',
													format: require('./rtermFormat')
												}												
											}
										]
									}									
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Effects correlation",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									style: "list",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "correlatedEffects_corr",
											optionName: "correlatedEffects",
											optionPart: "corr",
											events: [
												{ execute: require('./mixed.events').onEvent_corr }
											]
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "correlatedEffects_nocorr",
											optionName: "correlatedEffects",
											optionPart: "nocorr"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "correlatedEffects_block",
											optionName: "correlatedEffects",
											optionPart: "block"
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Factors Coding",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.ListBox,
					typeName: 'ListBox',
					name: "contrasts",
					stretchFactor: 1,
					showColumnHeaders: false,
					columns: [
						{
							name: "var",
							label: null,
							selectable: false,
							stretchFactor: 1,
							maxWidth: 300,
							template:
							{
								type: DefaultControls.VariableLabel,
								typeName: 'VariableLabel'
							}							
						},
						{
							name: "type",
							label: null,
							selectable: false,
							stretchFactor: 0.5,
							template:
							{
								type: DefaultControls.ComboBox,
								typeName: 'ComboBox'
							}							
						}
					]
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showRealNames"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showContrastCode"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Covariates Scaling",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.ListBox,
					typeName: 'ListBox',
					name: "scaling",
					stretchFactor: 1,
					showColumnHeaders: false,
					columns: [
						{
							name: "var",
							label: null,
							selectable: false,
							stretchFactor: 1,
							maxWidth: 300,
							template:
							{
								type: DefaultControls.VariableLabel,
								typeName: 'VariableLabel'
							}							
						},
						{
							name: "type",
							label: null,
							selectable: false,
							stretchFactor: 0.5,
							template:
							{
								type: DefaultControls.ComboBox,
								typeName: 'ComboBox'
							}							
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Covariates conditioning",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									style: "list",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScale_mean_sd",
											optionName: "simpleScale",
											optionPart: "mean_sd",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "cvalue",
													format: FormatDef.number
												}
											]
										},
										{
											name: "simpleScale_percent",
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											optionName: "simpleScale",
											optionPart: "percent",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "percvalue",
													label: null,
													suffix: "%",
													format: FormatDef.number,
													enable: "(simpleScale_percent)"
												}
											]
										}
									]
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Covariates labeling",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_labels",
											optionName: "simpleScaleLabels",
											optionPart: "labels"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_numbers",
											optionName: "simpleScaleLabels",
											optionPart: "values"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_numbers_labels",
											optionName: "simpleScaleLabels",
											optionPart: "values_labels"
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Post Hoc Tests",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Supplier,
					typeName: 'Supplier',
					name: "postHocSupplier",
					persistentItems: false,
					stretchFactor: 1,
					format: FormatDef.term,
					events: [
						{ execute: require('./mixed.events').onChange_postHocSupplier },
						{ onEvent: 'update', execute: require('./mixed.events').onUpdate_postHocSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "",
							controls: [
								{
									type: DefaultControls.ListBox,
									typeName: 'ListBox',
									name: "postHoc",
									isTarget: true,
									template:
									{
										type: DefaultControls.TermLabel,
										typeName: 'TermLabel'
									}									
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Correction",
							controls: [
								{
									name: "postHocCorr_none",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "none",
									optionName: "postHocCorr"
								},
								{
									name: "postHocCorr_bonf",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "bonf",
									optionName: "postHocCorr"
								},
								{
									name: "postHocCorr_holm",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "holm",
									optionName: "postHocCorr"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Plots",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					name: "plotsSupplier",
					populate: "manual",
					stretchFactor: 1,
					persistentItems: false,
					events: [
						{ execute: require('./gamlj.events').onChange_plotsSupplier },
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_plotsSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotHAxis",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotSepLines",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotSepPlots",
									isTarget: true,
									maxItemCount: 1
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Display",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "errBarDef_none",
									optionName: "plotError",
									optionPart: "none"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "errBarDef_ci",
									optionName: "plotError",
									optionPart: "ci",
									controls: [
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "ciWidth",
											label: "Interval",
											suffix: "%",
											format: FormatDef.number,
											enable: "(errBarDef_ci)"
										}
									]
								},
								{
									name: "plotError_se",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "plotError",
									optionPart: "se"
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Plot",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotRaw",
									enable: "(!plotLinearPred)"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotDvScale",
									enable: "(!plotLinearPred)"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotRandomEffects"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotLinearPred"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Simple Effects",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					name: "simpleSupplier",
					populate: "manual",
					stretchFactor: 1,
					persistentItems: false,
					events: [
						{ execute: require('./mixed.events').onChange_simpleSupplier },
						{ onEvent: 'update', execute: require('./mixed.events').onUpdate_simpleSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simpleVariable",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simpleModerator",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simple3way",
									isTarget: true,
									maxItemCount: 1
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Estimated Marginal Means",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Display",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "eDesc"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "eCovs",
							enable: "(eDesc)"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Options",
			style: "inline",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Estimation",
					controls: [
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "nAGQ",
							format: FormatDef.number
						}
					]
				},
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "CI Method",
					controls: [
						{
							type: DefaultControls.RadioButton,
							typeName: 'RadioButton',
							name: "cimethod_wald",
							optionName: "cimethod",
							optionPart: "wald"
						},
						{
							type: DefaultControls.RadioButton,
							typeName: 'RadioButton',
							name: "cimethod_profile",
							optionName: "cimethod",
							optionPart: "profile"
						},
						{
							type: DefaultControls.RadioButton,
							typeName: 'RadioButton',
							name: "cimethod_boot",
							optionName: "cimethod",
							optionPart: "boot"
						}
					]
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{"./gamlj.events":1,"./mixed.events":3,"./rtermFormat":4}],3:[function(require,module,exports){
var rtermFormat = require('./rtermFormat');

const events = {
    update: function(ui) {
        this.setCustomVariable("Intercept", "none", "");
        calcModelTerms(ui, this);
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);
        updateRandomSupplier(ui,this);
        fixRandomEffects(ui,this);

    },

    onChange_factors: function(ui) {
        calcModelTerms(ui, this);
        updateRandomSupplier(ui,this);
 
    },

    onChange_covariates: function(ui) {
        calcModelTerms(ui, this);
        updateRandomSupplier(ui,this);

    },
    onChange_cluster: function(ui) {
        updateRandomSupplier(ui,this);

    },

    onChange_randomSupplier: function(ui){
        let supplierList = this.itemsToValues(ui.randomSupplier.value());
        console.log("change in random supplier");
        var changes = this.findChanges("randomSupplier",supplierList,rtermFormat);
        if (changes.removed.length>0) {
          var randomTerms = this.cloneArray(ui.randomTerms.value(),[]);
          var  light = removeFromMultiList(changes.removed,randomTerms,this,1);
          ui.randomTerms.setValue(light);
        }
        return;
    },

    onChange_modelTerms: function(ui) {
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);
        updatePlotsSupplier(ui, this);
        updateRandomSupplier(ui,this);

    },

    onChange_plotsSupplier: function(ui) {
        let values = this.itemsToValues(ui.plotsSupplier.value());
        this.checkValue(ui.plotHAxis, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepLines, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepPlots, false, values, FormatDef.variable);
    },
    
    onChange_simpleSupplier: function(ui) {
        let values = this.itemsToValues(ui.simpleSupplier.value());
        this.checkValue(ui.simpleVariable, false, values, FormatDef.variable);
        this.checkValue(ui.simpleModerator, false, values, FormatDef.variable);
        this.checkValue(ui.simple3way, false, values, FormatDef.variable);
    },

 
    onChange_postHocSupplier: function(ui) {
        let values = this.itemsToValues(ui.postHocSupplier.value());
        this.checkValue(ui.postHoc, true, values, FormatDef.term);
    },
    onUpdate_postHocSupplier: function(ui) {
        updatePostHocSupplier(ui, this);
    },

    onUpdate_simpleSupplier: function(ui) {
        updateSimpleSupplier(ui, this);
    },
    onUpdate_plotsSupplier: function(ui) {
        updatePlotsSupplier(ui, this);
    },

    onUpdate_modelSupplier: function(ui) {
            let factorsList = this.cloneArray(ui.factors.value(), []);
            let covariatesList = this.cloneArray(ui.covs.value(), []);
            var variablesList = factorsList.concat(covariatesList);
            ui.modelSupplier.setValue(this.valuesToItems(variablesList, FormatDef.variable));
    },

    onUpdate_randomSupplier: function(ui) {
        updateRandomSupplier(ui,this);

    },


    onEvent_addRandomTerm: function(ui) {
        console.log("addRandomTerm does nothing");
    },
    onEvent_randomTerms_preprocess: function(ui, data) {
 //       for(var j = 0; j < data.items.length; j++) {
//          data.items[j].value.raw=data.items[j].value.toString();
//      }
    },
    onEvent_corr: function(ui, data) {
          console.log("Correlation structure changed");
          fixRandomEffects(ui,this);

    },    


   onEvent_nothing: function(ui, data) {
           // remove error notes if any
          console.log("I didn't do anything");
    }    

};

var fixRandomEffects = function(ui, context) {
            var option=ui.correlatedEffects.value();
            var oldOption = context.workspace.correlatedEffects;
            context.workspace.correlatedEffects=option;
          

            if (ui.correlatedEffects.value()=="block") {
                  if (oldOption==="corr" || oldOption==="nocorr")
                        ui.randomTerms.setValue(Array([]));
                  // make sure the add button is visible                      
                  var button= ui.randomTerms.$addButton;
                  button[0].style.visibility="visible";
                  // get the randomTerms field to manipulate the children
                  var target= ui.randomTerms;
                  target.$el[0].lastElementChild.style.borderColor=null;
                  target.controls[0].$el[0].childNodes[0].style.visibility="visible";
                  // remove possibility to kill the first row
                  target.controls[0].$el[0].childNodes[0].style.visibility="hidden";
                  

             } else {
                 var data = context.cloneArray(ui.randomTerms.value(),[]);
                 var one = flatMulti(data,context);
                 var button= ui.randomTerms.$addButton;
                 button[0].style.visibility="hidden";
                 var target= ui.randomTerms;
                 target.setValue(Array(one));
                 var one = target.controls[0];
                 target.$el[0].lastElementChild.style.borderColor="transparent";
                 one.$el[0].childNodes[0].style.visibility="hidden";
                 one.$el[0].childNodes[1].childNodes[0].style.borderStyle="unset";
             }

  
};

var calcModelTerms = function(ui, context) {
    var variableList = context.cloneArray(ui.factors.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var combinedList = variableList.concat(covariatesList);
    ui.modelSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.plotsSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.simpleSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
 
    var diff = context.findChanges("variableList", variableList, true, FormatDef.variable);
    var diff2 = context.findChanges("covariatesList", covariatesList, true, FormatDef.variable);
    var combinedDiff = context.findChanges("combinedList", combinedList, true, FormatDef.variable);


    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var termsChanged = false;

    for (var i = 0; i < combinedDiff.removed.length; i++) {
        for (var j = 0; j < termsList.length; j++) {
            if (FormatDef.term.contains(termsList[j], combinedDiff.removed[i])) {
                termsList.splice(j, 1);
                termsChanged = true;
                j -= 1;
            }
        }
    }


    for (var a = 0; a < diff.added.length; a++) {
        let item = diff.added[a];
        var listLength = termsList.length;
        for (var j = 0; j < listLength; j++) {
            var newTerm = context.clone(termsList[j]);
            if (containsCovariate(newTerm, covariatesList) === false) {
                if (context.listContains(newTerm, item, FormatDef.variable) === false) {
                    newTerm.push(item)
                    if (context.listContains(termsList, newTerm , FormatDef.term) === false) {
                        termsList.push(newTerm);
                        termsChanged = true;
                    }
                }
            }
        }
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    for (var a = 0; a < diff2.added.length; a++) {
        let item = diff2.added[a];
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    if (termsChanged)
        ui.modelTerms.setValue(termsList);

    updateContrasts(ui, variableList, context);
    updateScaling(ui, covariatesList, context);
};

var updateSimpleSupplier = function(ui, context) {
        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.simpleSupplier.setValue(varList);
    };



var updatePostHocSupplier = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var list = [];
    for (var j = 0; j < termsList.length; j++) {
        var term = termsList[j];
        if (containsCovariate(term, covariatesList) === false)
            list.push(term);
    }
    ui.postHocSupplier.setValue(context.valuesToItems(list, FormatDef.term));
};

var filterModelTerms = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var diff = context.findChanges("termsList", termsList, true, FormatDef.term);

    var changed = false;
    if (diff.removed.length > 0) {
        var itemsRemoved = false;
        for (var i = 0; i < diff.removed.length; i++) {
            var item = diff.removed[i];
            for (var j = 0; j < termsList.length; j++) {
                if (FormatDef.term.contains(termsList[j], item)) {
                    termsList.splice(j, 1);
                    j -= 1;
                    itemsRemoved = true;
                }
            }
        }

        if (itemsRemoved)
            changed = true;
    }

    if (context.sortArraysByLength(termsList))
        changed = true;

    if (changed)
        ui.modelTerms.setValue(termsList);
};

var updateContrasts = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.contrasts.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "simple" });
        else
            list3.push(found);
    }

    ui.contrasts.setValue(list3);
};

var updateScaling = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.scaling.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "centered" });
        else
            list3.push(found);
    }

    ui.scaling.setValue(list3);
};

var containsCovariate = function(value, covariates) {
    for (var i = 0; i < covariates.length; i++) {
        if (FormatDef.term.contains(value, covariates[i]))
            return true;
    }

    return false;
};


var updateRandomSupplier = function(ui, context) {
    var factorList = context.cloneArray(ui.factors.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var variableList = factorList.concat(covariatesList);
    var modelTerms = context.cloneArray(ui.modelTerms.value(), []); 
    var termsList=[];
    termsList = context.getCombinations(variableList);
    termsList=unique(termsList.concat(modelTerms));
    context.sortArraysByLength(termsList);
//    ui.randomSupplier.setValue(context.valuesToItems(termsList, FormatDef.term));
    var clusterList = context.cloneArray(ui.cluster.value(), []);
    if (clusterList.length<1) {
                ui.randomSupplier.setValue(context.valuesToItems([], rtermFormat));                  return;
    }
    termsList.unshift(["Intercept"]);
    var alist=[];
    for (var i=0; i < clusterList.length; i++) {
     for (var j = 0; j < termsList.length; j++) {
       var item=context.cloneArray(termsList[j]);
       item[item.length]=clusterList[i];
       alist.push(item);
     }
    }
    context.sortArraysByLength(alist);
    console.log("random supplierList");
    console.log(alist);
      var formatted=context.valuesToItems(alist, rtermFormat);
//    var busyList = context.cloneArray(ui.randomTerms.value(), []);
//    var busyForm = context.valuesToItems(busyList, rtermFormat);
//    var xunique = formatted.filter(function(val) {
//         return busyForm.indexOf(val) == -1;
//            });    
    ui.randomSupplier.setValue(formatted);
    
};


var filterRandomTerms = function(ui, context) {
    console.log("filter random effects");  
    var termsList = context.cloneArray(ui.randomTerms.value(), []);
    console.log(termsList);
    var unique = termsList.filter((v, i, a) => a.indexOf(v) === i); 
    if (unique.length!=termsList.length)
      ui.randomTerms.setValue(unique);
  
};


var updatePlotsSupplier = function(ui, context) {

        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.plotsSupplier.setValue(varList);
    
    };


var unique=function(arr) {
    var u = {}, a = [];
    for(var i = 0, l = arr.length; i < l; ++i){
        var prop=ssort(JSON.stringify(arr[i]));
        if(!u.hasOwnProperty(prop) && arr[i].length>0) {
            a.push(arr[i]);
            u[prop] = 1;
        }
    }
    return a;
};

var addToList = function(quantum, cosmos, context) {
  
    cosmos = normalize(context.cloneArray(cosmos));
    quantum = normalize(context.cloneArray(quantum));
    
    for (var i = 0; i < quantum.length; i++) {
          if (dim(quantum[i])===0)
              cosmos.push([quantum[i]]);
          if (dim(quantum[i])===1)
              cosmos.push(quantum[i]);
          }
    return unique(cosmos);
};

var flatMulti = function(cosmos,context) {
  var light = []
  for (var i=0 ; i < cosmos.length; i++) {
    light=addToList(light,cosmos[i],context);
  }
  return unique(light);
};



var ssort= function(str){
  str = str.replace(/[`\[\]"\\\/]/gi, '');
  var arr = str.split(',');
  var sorted = arr.sort();
  return sorted.join('');
}

var normalize = function(cosmos) {

  if (cosmos===undefined)
          return [];
  if (dim(cosmos)===0)
          cosmos=[cosmos]
          
        for (var i = 0; i < cosmos.length; i++) {
            var aValue = cosmos[i];
            var newValue=dim(aValue)>0 ? aValue : [aValue];
            cosmos[i]=newValue
        }
        return cosmos;
}

var removeFromMultiList = function(quantum, cosmos, context, strict = 1) {

    var cosmos = context.cloneArray(cosmos);
    var dimq = dim(quantum);
        for (var j = 0; j < cosmos.length; j++) 
           cosmos[j]=removeFromList(quantum,cosmos[j],context, strict);
    return(cosmos);
};



// remove a list or a item from list
// order=0 remove only if term and target term are equal
// order>0 remove if term length>=order 
// for instance, order=1 remove any matching interaction with terms, keeps main effects
// order=2 remove from 3-way interaction on (keep up to 2-way interactions)

var removeFromList = function(quantum, cosmos, context, order = 1) {

     cosmos=normalize(cosmos);
     quantum=normalize(quantum);
     if (cosmos===undefined)
        return([]);
     var cosmos = context.cloneArray(cosmos);
       for (var i = 0; i < cosmos.length; i++) {
          if (cosmos[i]===undefined)
             break;
          var aCosmos = context.cloneArray(cosmos[i]);
           for (var k = 0; k < quantum.length; k++) {
             var  test = order === 0 ? FormatDef.term.isEqual(aCosmos,quantum[k]) : FormatDef.term.contains(aCosmos,quantum[k]);
                 if (test && (aCosmos.length >= order)) {
                        cosmos.splice(i, 1);
                        i -= 1;
                    break;    
                    }
          }
            
       }
  
    return(cosmos);
};


var dim = function(aList) {

    if (!Array.isArray(aList))
           return(0);
    if (!Array.isArray(aList[0]))
           return(1);
    if (!Array.isArray(aList[0][0]))
           return(2);
    if (!Array.isArray(aList[0][0][0]))
           return(3);
    if (!Array.isArray(aList[0][0][0][0]))
           return(4);

  
    return(value);
};



module.exports = events;


},{"./rtermFormat":4}],4:[function(require,module,exports){
var rtermFormat = new Format ({
  
  name: 'term',
  
  default: null,
  
  toString: function(raw) {
    return rtermFormat._itemToString(raw, 0);
  },
  
  parse: function(value) {
    return "test";
  },
  
  isValid: function(raw) {
    return rtermFormat._validateItem(raw, 0);
  },
  
  isEqual: function(raw1, raw2) {
    return rtermFormat._areItemsEqual(raw1, raw2);
  },
  
  isEmpty: function(raw) {
    return raw === null;
  },
  
  contains: function(raw, value) {
    
    var type1 = typeof raw;
    var type2 = typeof value;
    
    if (type1 === 'string' && type2 === 'string')
      return raw === value;
      else if (type1 === 'string')
        return false;
      
      for (var j = 0; j < raw.length; j++) {
        
        if (rtermFormat.contains(raw[j], value))
          return true;
      }
      
      if (raw.length < value.length)
        return false;
      
      var jStart = 0;
      for (var i = 0; i < value.length; i++) {
        var found = false;
        for (var k = jStart; k < raw.length; k++) {
          if (rtermFormat._areItemsEqual(value[i], raw[k])) {
            if (jStart === k)
              jStart = k + 1;
            found = true;
            break;
          }
        }
        
        if (found === false)
          return false;
      }
      
      return true;
  },
  
  _areItemsEqual: function(item1, item2) {
    var type1 = typeof item1;
    var type2 = typeof item1;
    
    if (type1 !== type2)
      return false;
    
    if (type1=== 'string' && type2 === 'string')
      return item1 === item2;
      
      if (Array.isArray(item1) === false || Array.isArray(item2) === false)
        return false;
      
      if (item1.length !== item2.length)
        return false;
      
      var jStart = 0;
      for (var i = 0; i < item1.length; i++) {
        var found = false;
        for (var j = jStart; j < item2.length; j++) {
          if (rtermFormat._areItemsEqual(item1[i], item2[j])) {
            if (j === jStart)
              jStart = j + 1;
            found = true;
            break;
          }
        }
        if (found === false)
          return false;
      }
      
      return true;
  },
  
  _getJoiner: function(level) {
    if (level === 0)
    return ':';
//      return '✻';
//        return 'X';
    
    return '|';
  },

  getSuperscript: function(value) {
        return '<sup> ' + value + '</sup>';
    },
  
  _itemToString: function(item, level, power) {
//    console.log("rterm format used")
    if (typeof item === 'string')
         return item + (power > 1 ? this.getSuperscript(power) : '');

    var joiner = rtermFormat._getJoiner(level);

        let combined = '';
        let npower = 1;
        for (let i = 0; i < item.length; i++) {
            if (i < item.length - 1 && item[i] === item[i+1])
                npower += 1;
            else {
              if (i===(item.length-1))
                    joiner='|';
               combined = (combined !== '' ? (combined + ' ' + joiner + ' ') : '') + FormatDef.term._itemToString(item[i], level + 1, npower);
                npower = 1;
            }
}
    return combined;
  },
  
  _validateItem: function(item, level) {
    if (level > 0 && typeof item === 'string')
      return true;
    else if (level > 2 || Array.isArray(item) === false || item.length === 0)
      return false;
    
    for (var i = 0; i < item.length; i++) {
      if (rtermFormat._validateItem(item[i], level + 1) === false)
        return false;
    }
    
    return true;
  }
});

module.exports = rtermFormat;
},{}]},{},[2])(2)
});