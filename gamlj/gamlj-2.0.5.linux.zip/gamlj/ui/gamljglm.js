(function(f){if(typeof exports==="object"&&typeof module!=="undefined"){module.exports=f()}else if(typeof define==="function"&&define.amd){define([],f)}else{var g;if(typeof window!=="undefined"){g=window}else if(typeof global!=="undefined"){g=global}else if(typeof self!=="undefined"){g=self}else{g=this}g.module = f()}})(function(){var define,module,exports;return (function(){function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s}return e})()({1:[function(require,module,exports){
var rtermFormat = require('./rtermFormat');

const events = {
    update: function(ui) {
        calcModelTerms(ui, this);
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);

    },

    onChange_factors: function(ui) {
        calcModelTerms(ui, this);

    },

    onChange_covariates: function(ui) {
        calcModelTerms(ui, this);

    },

    onChange_modelTerms: function(ui) {
        filterModelTerms(ui, this);
        updatePostHocSupplier(ui, this);
        updateSimpleSupplier(ui, this);

    },

    onChange_plotsSupplier: function(ui) {
        let values = this.itemsToValues(ui.plotsSupplier.value());
        this.checkValue(ui.plotHAxis, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepLines, false, values, FormatDef.variable);
        this.checkValue(ui.plotSepPlots, false, values, FormatDef.variable);
    },
    
    onChange_simpleSupplier: function(ui) {
          console.log("change simple");
        let values = this.itemsToValues(ui.simpleSupplier.value());
        this.checkValue(ui.simpleVariable, false, values, FormatDef.variable);
        this.checkValue(ui.simpleModerator, false, values, FormatDef.variable);
        this.checkValue(ui.simple3way, false, values, FormatDef.variable);
    },

    onUpdate_simpleSupplier: function(ui) {
        updateSimpleSupplier(ui, this);
    },
    onUpdate_plotsSupplier: function(ui) {
        updatePlotsSupplier(ui, this);
    },

     onChange_model: function(ui) {
        console.log("model changed");
        if (typeof ui.effectSize_RR !== 'undefined' ) {
              ui.effectSize_RR.setValue(false);
        }
        if (ui.modelSelection.getValue()==="custom" ||  ui.modelSelection.getValue()==="linear") {
               ui.effectSize_expb.setValue(false);
               ui.showParamsCI.setValue(true);
               ui.showExpbCI.setValue(false);
        } else  {
               ui.effectSize_expb.setValue(true);
               ui.showParamsCI.setValue(false);
               ui.showExpbCI.setValue(true);
        }
  
        ui.dep.setValue(null);
      },

    onChange_postHocSupplier: function(ui) {
        let values = this.itemsToValues(ui.postHocSupplier.value());
        this.checkValue(ui.postHoc, true, values, FormatDef.term);
    },

    onUpdate_postHocSupplier: function(ui) {
        updatePostHocSupplier(ui, this);
    },
    
    onUpdate_modelSupplier: function(ui) {
            let factorsList = this.cloneArray(ui.factors.value(), []);
            let covariatesList = this.cloneArray(ui.covs.value(), []);
            var variablesList = factorsList.concat(covariatesList);
            ui.modelSupplier.setValue(this.valuesToItems(variablesList, FormatDef.variable));
    }
};

var calcModelTerms = function(ui, context) {
    var variableList = context.cloneArray(ui.factors.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var combinedList = variableList.concat(covariatesList);
    ui.modelSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.plotsSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
    ui.simpleSupplier.setValue(context.valuesToItems(combinedList, FormatDef.variable));
 
    var diff = context.findChanges("variableList", variableList, true, FormatDef.variable);
    var diff2 = context.findChanges("covariatesList", covariatesList, true, FormatDef.variable);
    var combinedDiff = context.findChanges("combinedList", combinedList, true, FormatDef.variable);


    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var termsChanged = false;

    for (var i = 0; i < combinedDiff.removed.length; i++) {
        for (var j = 0; j < termsList.length; j++) {
            if (FormatDef.term.contains(termsList[j], combinedDiff.removed[i])) {
                termsList.splice(j, 1);
                termsChanged = true;
                j -= 1;
            }
        }
    }


    for (var a = 0; a < diff.added.length; a++) {
        let item = diff.added[a];
        var listLength = termsList.length;
        for (var j = 0; j < listLength; j++) {
            var newTerm = context.clone(termsList[j]);
            if (containsCovariate(newTerm, covariatesList) === false) {
                if (context.listContains(newTerm, item, FormatDef.variable) === false) {
                    newTerm.push(item)
                    if (context.listContains(termsList, newTerm , FormatDef.term) === false) {
                        termsList.push(newTerm);
                        termsChanged = true;
                    }
                }
            }
        }
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    for (var a = 0; a < diff2.added.length; a++) {
        let item = diff2.added[a];
        if (context.listContains(termsList, [item] , FormatDef.term) === false) {
            termsList.push([item]);
            termsChanged = true;
        }
    }

    if (termsChanged)
        ui.modelTerms.setValue(termsList);

    updateContrasts(ui, variableList, context);
    updateScaling(ui, covariatesList, context);
};

var updateSimpleSupplier = function(ui, context) {
      
        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.simpleSupplier.setValue(varList);
    };

var updatePlotsSupplier = function(ui, context) {

        var termsList = context.cloneArray(ui.modelTerms.value(), []);
        var varList=[];
        for (var j = 0; j < termsList.length; j++) {
            var newTerm=context.clone(termsList[j]);
            if (newTerm.length==1) {
                  varList.push(newTerm[0]); // was varList.push(newTerm);
            }
        }
        varList=context.valuesToItems(varList, FormatDef.variable);
        ui.plotsSupplier.setValue(varList);
    
    };


var updatePostHocSupplier = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var covariatesList = context.cloneArray(ui.covs.value(), []);
    var list = [];
    for (var j = 0; j < termsList.length; j++) {
        var term = termsList[j];
        if (containsCovariate(term, covariatesList) === false)
            list.push(term);
    }
    ui.postHocSupplier.setValue(context.valuesToItems(list, FormatDef.term));
};

var filterModelTerms = function(ui, context) {
    var termsList = context.cloneArray(ui.modelTerms.value(), []);
    var diff = context.findChanges("termsList", termsList, true, FormatDef.term);

    var changed = false;
    if (diff.removed.length > 0) {
        var itemsRemoved = false;
        for (var i = 0; i < diff.removed.length; i++) {
            var item = diff.removed[i];
            for (var j = 0; j < termsList.length; j++) {
                if (FormatDef.term.contains(termsList[j], item)) {
                    termsList.splice(j, 1);
                    j -= 1;
                    itemsRemoved = true;
                }
            }
        }

        if (itemsRemoved)
            changed = true;
    }

    if (context.sortArraysByLength(termsList))
        changed = true;

    if (changed)
        ui.modelTerms.setValue(termsList);
};

var updateContrasts = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.contrasts.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "simple" });
        else
            list3.push(found);
    }

    ui.contrasts.setValue(list3);
};

var updateScaling = function(ui, variableList, context) {
    var currentList = context.cloneArray(ui.scaling.value(), []);

    var list3 = [];
    for (let i = 0; i < variableList.length; i++) {
        let found = null;
        for (let j = 0; j < currentList.length; j++) {
            if (currentList[j].var === variableList[i]) {
                found = currentList[j];
                break;
            }
        }
        if (found === null)
            list3.push({ var: variableList[i], type: "centered" });
        else
            list3.push(found);
    }

    ui.scaling.setValue(list3);
};

var containsCovariate = function(value, covariates) {
    for (var i = 0; i < covariates.length; i++) {
        if (FormatDef.term.contains(value, covariates[i]))
            return true;
    }

    return false;
};





module.exports = events;


},{"./rtermFormat":3}],2:[function(require,module,exports){

// This file is an automatically generated and should not be edited

'use strict';

const options = [{"name":"data","type":"Data","description":{"R":"the data as a data frame"}},{"name":"dep","title":"Dependent Variable","type":"Variable","default":null,"suggested":["continuous","ordinal"],"permitted":["numeric"],"description":{"R":"a string naming the dependent variable from `data`; the variable must be numeric. No needed if `formula` is used.\n"}},{"name":"factors","title":"Factors","type":"Variables","suggested":["nominal"],"permitted":["factor"],"default":null,"description":{"R":"a vector of strings naming the fixed factors from `data`. No needed if `formula` is used."}},{"name":"covs","title":"Covariates","type":"Variables","permitted":["numeric"],"default":null,"description":{"R":"a vector of strings naming the covariates from `data`. No needed if `formula` is used."}},{"name":"modelTerms","title":"Model Terms","type":"Terms","default":null,"description":{"R":"a list of character vectors describing fixed effects terms. No needed if `formula` is used.\n"}},{"name":"fixedIntercept","title":"Fixed Intercept","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE`, estimates fixed intercept. No needed if `formula` is used.\n"}},{"name":"showParamsCI","title":"Confidence intervals","type":"Bool","default":true,"description":{"R":"`TRUE` (default) or `FALSE` , parameters CI in table\n"}},{"name":"paramCIWidth","title":"Confidence level","type":"Number","min":50,"max":99.9,"default":95,"description":{"R":"a number between 50 and 99.9 (default: 95) specifying the confidence interval width for the parameter estimates\n"}},{"name":"contrasts","title":"Factors Coding","type":"Array","items":"(factors)","default":null,"template":{"type":"Group","elements":[{"name":"var","type":"Variable","content":"$key"},{"name":"type","type":"List","options":["simple","deviation","dummy","difference","helmert","repeated","polynomial"],"default":"simple"}]},"description":{"R":"a list of lists specifying the factor and type of contrast to use, one of `'deviation'`, `'simple'`, `'difference'`, `'helmert'`, `'repeated'` or `'polynomial'`. If NULL, `simple` is used.\n"}},{"name":"showRealNames","title":"Names in estimates table","type":"Bool","default":true,"description":{"R":"`TRUE` or `FALSE` (default), shows raw names of the contrasts variables\n"}},{"name":"showContrastCode","title":"Contrast Coefficients tables","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), shows contrast coefficients tables\n"}},{"name":"plotHAxis","title":"Horizontal axis","type":"Variable","default":null,"description":{"R":"a string naming the variable placed on the horizontal axis of the plot\n"}},{"name":"plotSepLines","title":"Separate lines","type":"Variable","default":null,"description":{"R":"a string naming the variable represented as separate lines in the plot\n"}},{"name":"plotSepPlots","title":"Separate plots","type":"Variable","default":null,"description":{"R":"a string naming the variable defining the levels for multiple plots\n"}},{"name":"plotRaw","title":"Observed scores","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), plot raw data along the predicted values\n"}},{"name":"plotDvScale","title":"Y-axis observed range","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), set the Y-axis range equal to the range of the observed values.\n"}},{"name":"plotError","title":"Error Bar Definition","type":"List","options":[{"name":"none","title":"None"},{"name":"ci","title":"Confidence intervals"},{"name":"se","title":"Standard Error"}],"default":"none","description":{"R":"`'none'` (default), `'ci'`, or `'se'`. Use no error bars, use confidence intervals, or use standard errors on the plots, respectively.\n"}},{"name":"ciWidth","title":"Confidence level","type":"Number","min":50,"max":99.9,"default":95,"description":{"R":"a number between 50 and 99.9 (default: 95) specifying the confidence interval width for the plots.\n"}},{"name":"postHoc","title":"Post Hoc Tests","type":"Terms","default":null,"description":{"R":"a list of terms to perform post-hoc tests on."}},{"name":"eDesc","title":"Estimated Marginal Means","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide lsmeans statistics\n"}},{"name":"eCovs","title":"Include covariates","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide lsmeans statistics conditioned to  different values of the continuous variables in the model. Which levels of the continuous variable should be used is set by the `simpleScale` option.\n"}},{"name":"simpleVariable","title":"Simple effects variable","type":"Variable","default":null,"description":{"R":"The variable for which the simple effects (slopes) are computed\n"}},{"name":"simpleModerator","title":"Moderator","type":"Variable","default":null,"description":{"R":"the variable that provides the levels at which the simple effects are computed\n"}},{"name":"simple3way","title":"Breaking variable","type":"Variable","default":null,"description":{"R":"a moderator of the two-way interaction which is probed\n"}},{"name":"simpleScale","title":"Covariates conditioning","type":"List","options":[{"name":"mean_sd","title":"Mean ±  SD"},{"name":"percent","title":"Percentiles 50 ± offset"}],"default":"mean_sd","description":{"R":"`'mean_sd'` (default), `'custom'` , or `'percent'`. Use to condition the covariates (if any)\n"}},{"name":"cvalue","type":"Number","default":1,"description":{"R":"how many st.deviations around the means used to condition simple effects and plots. Used if `simpleScale`=`'mean_sd'`\n"}},{"name":"percvalue","type":"Number","default":25,"min":5,"max":50,"description":{"R":"offsett (number of percentiles) around the median used to condition simple effects and plots. Used if `simpleScale`=`'percent'`\n"}},{"name":"simpleScaleLabels","title":"Moderators labeling","type":"List","options":[{"name":"labels","title":"Labels"},{"name":"values","title":"Values"},{"name":"values_labels","title":"Values + Labels"}],"default":"labels","description":{"R":"how the levels of a continuous moderator should appear in tables and plots: `labels`, `values` and `values_labels`. \n"}},{"name":"postHocCorr","title":"Correction","type":"NMXList","options":[{"name":"none","title":"No correction"},{"name":"bonf","title":"Bonferroni"},{"name":"tukey","title":"Tukey"},{"name":"holm","title":"Holm"}],"default":["bonf"],"description":{"R":"one or more of `'none'`,  `'bonf'`, or `'holm'`; provide no,  Bonferroni, and Holm Post Hoc corrections respectively.\n"}},{"name":"scaling","title":"Covariates Scaling","type":"Array","items":"(covs)","default":null,"template":{"type":"Group","elements":[{"name":"var","type":"Variable","content":"$key"},{"name":"type","type":"List","options":["centered","standardized","none"],"default":"centered"}]},"description":{"R":"a list of lists specifying the covariates scaling, one of `'centered'` to the mean, `'standardized'`, or `'none'`. `'none'` leaves the variable as it is\n"}},{"name":"effectSize","title":"Effect Size","type":"NMXList","options":[{"name":"eta","title":"η²"},{"name":"partEta","title":"partial η²"},{"name":"omega","title":"ω²"},{"name":"beta","title":"β"}],"default":["beta","partEta"],"description":{"R":"a list of effect sizes to print out. They can be: `'eta'` for eta-square, `'partEta'` for partial eta-square, `'omega'` for omega-square, and `'beta'` for standardized coefficients (betas). Default is `beta` and `partial eta-squared`.\n"}},{"name":"homoTest","title":"Residual Variances Homogeneity tests","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), perform homogeneity tests\n"}},{"name":"qq","title":"Q-Q plot of residuals","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide a Q-Q plot of residuals\n"}},{"name":"normTest","title":"Normality of residuals","type":"Bool","default":false,"description":{"R":"`TRUE` or `FALSE` (default), provide a test for normality of residuals\n"}}];

const view = function() {
    
    

    View.extend({
        jus: "2.0",

        events: [

	],

	update: require('./gamlj.events').update

    }).call(this);
}

view.layout = ui.extend({

    label: "General Linear Model",
    jus: "2.0",
    type: "root",
    stage: 0, //0 - release, 1 - development, 2 - proposed
    controls: [
		{
			type: DefaultControls.VariableSupplier,
			typeName: 'VariableSupplier',
			name: "variablesupplier",
			suggested: ["continuous","nominal","ordinal"],
			persistentItems: false,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "dep",
							maxItemCount: 1,
							isTarget: true,
							itemDropBehaviour: "overwrite"
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "factors",
							isTarget: true,
							events: [
								{ execute: require('./gamlj.events').onChange_factors }
							]
						}
					]
				},
				{
					type: DefaultControls.TargetLayoutBox,
					typeName: 'TargetLayoutBox',
					controls: [
						{
							type: DefaultControls.VariablesListBox,
							typeName: 'VariablesListBox',
							name: "covs",
							height: "small",
							isTarget: true,
							events: [
								{ execute: require('./gamlj.events').onChange_covariates }
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.LayoutBox,
			typeName: 'LayoutBox',
			margin: "large",
			style: "inline",
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Effect Size",
					margin: "large",
					style: "list-inline",
					controls: [
						{
							name: "effectSize_beta",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							optionPart: "beta",
							optionName: "effectSize"
						},
						{
							name: "effectSize_eta",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							optionPart: "eta",
							optionName: "effectSize"
						},
						{
							name: "effectSize_partEta",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							optionPart: "partEta",
							optionName: "effectSize"
						},
						{
							name: "effectSize_omega",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							optionPart: "omega",
							optionName: "effectSize"
						}
					]
				},
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Confidence Intervals",
					margin: "large",
					style: "list-inline",
					controls: [
						{
							name: "showParamsCI",
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox'
						},
						{
							type: DefaultControls.TextBox,
							typeName: 'TextBox',
							name: "paramCIWidth",
							label: "Interval",
							suffix: "%",
							format: FormatDef.number,
							enable: "(showParamsCI)"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Model",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Supplier,
					typeName: 'Supplier',
					name: "modelSupplier",
					label: "Components",
					persistentItems: true,
					stretchFactor: 1,
					format: FormatDef.term,
					higherOrders: true,
					events: [
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_modelSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							transferAction: "interactions",
							controls: [
								{
									type: DefaultControls.ListBox,
									typeName: 'ListBox',
									name: "modelTerms",
									valueFilter: "unique",
									isTarget: true,
									itemDropBehaviour: "emptyspace",
									events: [
										{ execute: require('./gamlj.events').onChange_modelTerms }
									],
									template:
									{
										type: DefaultControls.TermLabel,
										typeName: 'TermLabel'
									}									
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "fixedIntercept"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Factors Coding",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.ListBox,
					typeName: 'ListBox',
					name: "contrasts",
					stretchFactor: 1,
					showColumnHeaders: false,
					columns: [
						{
							name: "var",
							label: null,
							selectable: false,
							stretchFactor: 1,
							maxWidth: 300,
							template:
							{
								type: DefaultControls.VariableLabel,
								typeName: 'VariableLabel'
							}							
						},
						{
							name: "type",
							label: null,
							selectable: false,
							stretchFactor: 0.5,
							template:
							{
								type: DefaultControls.ComboBox,
								typeName: 'ComboBox'
							}							
						}
					]
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showRealNames"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "showContrastCode"
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Covariates Scaling",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.ListBox,
					typeName: 'ListBox',
					name: "scaling",
					stretchFactor: 1,
					showColumnHeaders: false,
					columns: [
						{
							name: "var",
							label: null,
							selectable: false,
							stretchFactor: 1,
							maxWidth: 300,
							template:
							{
								type: DefaultControls.VariableLabel,
								typeName: 'VariableLabel'
							}							
						},
						{
							name: "type",
							label: null,
							selectable: false,
							stretchFactor: 0.5,
							template:
							{
								type: DefaultControls.ComboBox,
								typeName: 'ComboBox'
							}							
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Covariates conditioning",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									style: "list",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScale_mean_sd",
											optionName: "simpleScale",
											optionPart: "mean_sd",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "cvalue",
													format: FormatDef.number
												}
											]
										},
										{
											name: "simpleScale_percent",
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											optionName: "simpleScale",
											optionPart: "percent",
											controls: [
												{
													type: DefaultControls.TextBox,
													typeName: 'TextBox',
													name: "percvalue",
													label: null,
													suffix: "%",
													format: FormatDef.number,
													enable: "(simpleScale_percent)"
												}
											]
										}
									]
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Covariates labeling",
							controls: [
								{
									type: DefaultControls.LayoutBox,
									typeName: 'LayoutBox',
									margin: "large",
									controls: [
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_labels",
											optionName: "simpleScaleLabels",
											optionPart: "labels"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_numbers",
											optionName: "simpleScaleLabels",
											optionPart: "values"
										},
										{
											type: DefaultControls.RadioButton,
											typeName: 'RadioButton',
											name: "simpleScaleLabels_numbers_labels",
											optionName: "simpleScaleLabels",
											optionPart: "values_labels"
										}
									]
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Post Hoc Tests",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Supplier,
					typeName: 'Supplier',
					name: "postHocSupplier",
					persistentItems: false,
					stretchFactor: 1,
					format: FormatDef.term,
					events: [
						{ execute: require('./gamlj.events').onChange_postHocSupplier },
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_postHocSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							label: "",
							controls: [
								{
									type: DefaultControls.ListBox,
									typeName: 'ListBox',
									name: "postHoc",
									isTarget: true,
									template:
									{
										type: DefaultControls.TermLabel,
										typeName: 'TermLabel'
									}									
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Correction",
							controls: [
								{
									name: "postHocCorr_none",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "none",
									optionName: "postHocCorr"
								},
								{
									name: "postHocCorr_bonf",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "bonf",
									optionName: "postHocCorr"
								},
								{
									name: "postHocCorr_tukey",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "tukey",
									optionName: "postHocCorr"
								},
								{
									name: "postHocCorr_holm",
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									optionPart: "holm",
									optionName: "postHocCorr"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Plots",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					name: "plotsSupplier",
					populate: "manual",
					stretchFactor: 1,
					persistentItems: false,
					events: [
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_plotsSupplier },
						{ execute: require('./gamlj.events').onChange_plotsSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotHAxis",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotSepLines",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "plotSepPlots",
									isTarget: true,
									maxItemCount: 1
								}
							]
						}
					]
				},
				{
					type: DefaultControls.LayoutBox,
					typeName: 'LayoutBox',
					margin: "large",
					style: "inline",
					controls: [
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Display",
							controls: [
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "errBarDef_none",
									optionName: "plotError",
									optionPart: "none"
								},
								{
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									name: "errBarDef_ci",
									optionName: "plotError",
									optionPart: "ci",
									controls: [
										{
											type: DefaultControls.TextBox,
											typeName: 'TextBox',
											name: "ciWidth",
											label: "Interval",
											suffix: "%",
											format: FormatDef.number,
											enable: "(errBarDef_ci)"
										}
									]
								},
								{
									name: "plotError_se",
									type: DefaultControls.RadioButton,
									typeName: 'RadioButton',
									optionName: "plotError",
									optionPart: "se"
								}
							]
						},
						{
							type: DefaultControls.Label,
							typeName: 'Label',
							label: "Plot",
							controls: [
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotRaw"
								},
								{
									type: DefaultControls.CheckBox,
									typeName: 'CheckBox',
									name: "plotDvScale"
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Simple Effects",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.VariableSupplier,
					typeName: 'VariableSupplier',
					name: "simpleSupplier",
					populate: "manual",
					stretchFactor: 1,
					persistentItems: false,
					events: [
						{ execute: require('./gamlj.events').onChange_simpleSupplier },
						{ onEvent: 'update', execute: require('./gamlj.events').onUpdate_simpleSupplier }
					],
					controls: [
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simpleVariable",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simpleModerator",
									isTarget: true,
									maxItemCount: 1
								}
							]
						},
						{
							type: DefaultControls.TargetLayoutBox,
							typeName: 'TargetLayoutBox',
							controls: [
								{
									type: DefaultControls.VariablesListBox,
									typeName: 'VariablesListBox',
									name: "simple3way",
									isTarget: true,
									maxItemCount: 1
								}
							]
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Estimated Marginal Means",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.Label,
					typeName: 'Label',
					label: "Display",
					controls: [
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "eDesc"
						},
						{
							type: DefaultControls.CheckBox,
							typeName: 'CheckBox',
							name: "eCovs",
							enable: "(eDesc)"
						}
					]
				}
			]
		},
		{
			type: DefaultControls.CollapseBox,
			typeName: 'CollapseBox',
			label: "Assumption Checks",
			collapsed: true,
			stretchFactor: 1,
			controls: [
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "homoTest",
					label: "Homogeneity tests"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "normTest",
					label: "Test normality of residuals"
				},
				{
					type: DefaultControls.CheckBox,
					typeName: 'CheckBox',
					name: "qq",
					label: "Q-Q plot of residuals"
				}
			]
		}
	]
});

module.exports = { view : view, options: options };

},{"./gamlj.events":1}],3:[function(require,module,exports){
var rtermFormat = new Format ({
  
  name: 'term',
  
  default: null,
  
  toString: function(raw) {
    return rtermFormat._itemToString(raw, 0);
  },
  
  parse: function(value) {
    return "test";
  },
  
  isValid: function(raw) {
    return rtermFormat._validateItem(raw, 0);
  },
  
  isEqual: function(raw1, raw2) {
    return rtermFormat._areItemsEqual(raw1, raw2);
  },
  
  isEmpty: function(raw) {
    return raw === null;
  },
  
  contains: function(raw, value) {
    
    var type1 = typeof raw;
    var type2 = typeof value;
    
    if (type1 === 'string' && type2 === 'string')
      return raw === value;
      else if (type1 === 'string')
        return false;
      
      for (var j = 0; j < raw.length; j++) {
        
        if (rtermFormat.contains(raw[j], value))
          return true;
      }
      
      if (raw.length < value.length)
        return false;
      
      var jStart = 0;
      for (var i = 0; i < value.length; i++) {
        var found = false;
        for (var k = jStart; k < raw.length; k++) {
          if (rtermFormat._areItemsEqual(value[i], raw[k])) {
            if (jStart === k)
              jStart = k + 1;
            found = true;
            break;
          }
        }
        
        if (found === false)
          return false;
      }
      
      return true;
  },
  
  _areItemsEqual: function(item1, item2) {
    var type1 = typeof item1;
    var type2 = typeof item1;
    
    if (type1 !== type2)
      return false;
    
    if (type1=== 'string' && type2 === 'string')
      return item1 === item2;
      
      if (Array.isArray(item1) === false || Array.isArray(item2) === false)
        return false;
      
      if (item1.length !== item2.length)
        return false;
      
      var jStart = 0;
      for (var i = 0; i < item1.length; i++) {
        var found = false;
        for (var j = jStart; j < item2.length; j++) {
          if (rtermFormat._areItemsEqual(item1[i], item2[j])) {
            if (j === jStart)
              jStart = j + 1;
            found = true;
            break;
          }
        }
        if (found === false)
          return false;
      }
      
      return true;
  },
  
  _getJoiner: function(level) {
    if (level === 0)
    return ':';
//      return '✻';
//        return 'X';
    
    return '|';
  },

  getSuperscript: function(value) {
        return '<sup> ' + value + '</sup>';
    },
  
  _itemToString: function(item, level, power) {
//    console.log("rterm format used")
    if (typeof item === 'string')
         return item + (power > 1 ? this.getSuperscript(power) : '');

    var joiner = rtermFormat._getJoiner(level);

        let combined = '';
        let npower = 1;
        for (let i = 0; i < item.length; i++) {
            if (i < item.length - 1 && item[i] === item[i+1])
                npower += 1;
            else {
              if (i===(item.length-1))
                    joiner='|';
               combined = (combined !== '' ? (combined + ' ' + joiner + ' ') : '') + FormatDef.term._itemToString(item[i], level + 1, npower);
                npower = 1;
            }
}
    return combined;
  },
  
  _validateItem: function(item, level) {
    if (level > 0 && typeof item === 'string')
      return true;
    else if (level > 2 || Array.isArray(item) === false || item.length === 0)
      return false;
    
    for (var i = 0; i < item.length; i++) {
      if (rtermFormat._validateItem(item[i], level + 1) === false)
        return false;
    }
    
    return true;
  }
});

module.exports = rtermFormat;
},{}]},{},[2])(2)
});